/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charges.strategy;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import ict4305.university.parking.Address;
import ict4305.university.parking.Car;
import ict4305.university.parking.CarType;
import ict4305.university.parking.Money;
import ict4305.university.parking.ParkingLot;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class HourlyRateStrategyTest {
	// Test hourly charge for a compact car (with a 25% surcharge and 20% discount)
    @Test
    public void testHourlyChargeForCompactCar() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Use a base rate of 500 cents and inject HourlyRateStrategy with new Money(500).
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 500L, new HourlyRateStrategy(new Money(500)));
        
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);  // Entry at 9:00 AM
        LocalDateTime exitTime  = LocalDateTime.of(2025, 4, 1, 12, 30); // Exit at 12:30 PM
        Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001");
        
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
        
        // Expect the charge to format as "$17.25"
        assertEquals("$16.00", charge.toString());
    }


    // Test hourly charge for an SUV car (with a 25% surcharge and no compact discount)
    @Test
    public void testHourlyChargeForSUVCar() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 500L, new HourlyRateStrategy(new Money(500)));
        
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0); // Entry at 9:00 AM
        LocalDateTime exitTime  = LocalDateTime.of(2025, 4, 1, 12, 30); // Exit at 12:30 PM
        Car suvCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001");
        
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, suvCar);
        
        assertEquals("$20.00", charge.toString());
    }


		
	// Testing for an hourly charge with a compact car with overnight
	// Testing for an hourly charge with the following scenario:
	// Hourly parking from 5:40AM on Tuesday April 1, 2025 to 9:10AM on Tuesday April 1, 2025
	// Due to hours, customer would be charged overnight fee and the compact car is a 20% discount
	@Test
	public void testHourlyOvernightChargeForCompactCar() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 500, new HourlyRateStrategy(new Money(500)));
			
		LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 3, 40); // Entry at 3:40AM
		LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 5, 10); // Exit at 5:10AM
		Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001");
			
		Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
			
		assertEquals("$23.00", charge.toString());
		}
		
	
	// Testing for an hourly charge with the following scenario:
	// Hourly parking from 5:40AM on Tuesday April 1, 2025 to 9:10AM on Tuesday April 1, 2025
	// Due to hours, customer would be charged overnight fee and there would be no compact discount
	@Test
	public void testHourlyOvernightChargeForSUVCar() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 500, new HourlyRateStrategy(new Money(500)));
				
		LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 1, 40); // Entry at 1:40AM
		LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 5, 10); // Exit at 5:10AM
		Car carSUV = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001");
				
		Money charge = lot.calculateParkingCharge(entryTime, exitTime, carSUV);
				
		assertEquals("$35.00", charge.toString());
		}
	
	
	// Testing for an hourly charge with the following scenario:
	// Hourly parking from 10:00AM on Saturday April 5, 2025 to 2:30PM on Saturday April 5, 2025
	// Due to hours would see a 25% surcharge and customer would receive a 20% discount for the  
	// weekend as well as the 20% discount for a compact car
	@Test
	public void testHourlyChargeForCompactDuringWeekend() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 600, new HourlyRateStrategy(new Money(600)));

	    LocalDateTime entryTime = LocalDateTime.of(2025, 4, 5, 10, 0); // Saturday entry at 10 AM
	    LocalDateTime exitTime = LocalDateTime.of(2025, 4, 5, 14, 30); // Exit at 2:30 PM
	    Car suv = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001");

	    Money charge = lot.calculateParkingCharge(entryTime, exitTime, suv);

	    assertEquals("$19.20", charge.toString());
		}
	
	
	// Testing for a weekend discount using and SUV
	// Testing for an hourly charge with the following scenario:
	// Hourly parking from 10:00AM on Saturday April 5, 2025 to 2:30PM on Saturday April 5, 2025
	// Due to hours would see a 25% surcharge and customer would receive a 20% discount for the  
	// weekend with no compact car discount
	@Test
	public void testHourlyChargeForSUVDuringWeekend() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 600, new HourlyRateStrategy(new Money(600)));

	     LocalDateTime entryTime = LocalDateTime.of(2025, 4, 5, 10, 0); // Saturday entry at 10 AM
	     LocalDateTime exitTime = LocalDateTime.of(2025, 4, 5, 14, 30); // Exit at 2:30 PM
	     Car suv = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001");

		 Money charge = lot.calculateParkingCharge(entryTime, exitTime, suv);

	     assertEquals("$24.00", charge.toString());
	     }

	// Testing for an hourly charge with the following scenario:
	// Hourly parking on Graduation day 2:00PM on Friday May 16, 2025 to 6:00PM on Friday May 16, 2025
	// Due to hours would see a 25% surcharge for time of day. Customer would receive a 50% surcharge for   
	// Graduation as well as the 20% discount for a compact car
	@Test
	public void testHourlyChargeOnGraduationDay() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 700, new HourlyRateStrategy(new Money(700)));

	     LocalDateTime entryTime = LocalDateTime.of(2025, 5, 16, 14, 0); // Graduation day entry at 2 PM
	     LocalDateTime exitTime = LocalDateTime.of(2025, 5, 16, 18, 0); // Exit at 6 PM
	     Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001");

		Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);

	     assertEquals("$33.60", charge.toString());
	     }
	
	
	/*// Testing for an hourly charge with the following scenario:
	// Hourly parking on Home coming day 2:00PM on Saturday October 11, 2025 to 6:00PM on Saturday October 11, 2025
	// Due to hours would see a 25% surcharge for time of day. Customer would receive a 25% surcharge for   
	// Home coming with no compact car discount
	@Test
	public void testHourlyChargeOnHomeComingDay() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 700, new HourlyRateStrategy(new Money(700)));

	     LocalDateTime entryTime = LocalDateTime.of(2025, 10, 11, 14, 0); // Homecoming day entry at 2 PM
	     LocalDateTime exitTime = LocalDateTime.of(2025, 10, 11, 18, 0); // Exit at 6 PM
	     Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001");

	     Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);

	     assertEquals("$17.92", charge.toString());
	     }
	     */
	     
}
