/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charges.strategy;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import ict4305.university.parking.Money;
import ict4305.university.parking.ParkingLot;
import ict4305.university.parking.Address;
import ict4305.university.parking.Car;
import ict4305.university.parking.CarType;

class ParkingChargeStrategyTest {

	// Testing per entry charge with the following scenario:
	// Parking from 9AM on Tuesday April 1, 2025 to 12:30PM on Tuesday April 1, 2025
	// Due to hours, there is a surcharge of 25% and the compact car is a 20% discount
	@Test
    public void testPerEntryChargeForCompactCar() {
        // Create an address for the parking lot.
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        
        // Create the parking lot with a base rate of 1200 cents.
        // Note: Passing 1200L for the base rate and initializing the PerEntryStrategy with 1200 cents.
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 1200L, new PerEntryStrategy(new Money(1200)));
        
        // Define the entry and exit times.
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);   // Entry at 9:00 AM
        LocalDateTime exitTime  = LocalDateTime.of(2025, 4, 1, 12, 30);  // Exit at 12:30 PM
        
        // Create a compact car.
        Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001");
        
        // Calculate the parking charge using ParkingLot's calculateParkingCharge method.
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
        
        // Expected charge calculation:
        // The per-entry strategy applies a discount for compact cars:
        // For a base rate of 1200 cents with a 20% discount, the effective rate is 1200 * 0.8 = 960 cents.
        // 960 cents formatted as dollars equals "$9.60".
        assertEquals("$9.60", charge.toString());
    }


	
	// Testing for an hourly charge with the following scenario:
	// Hourly parking from 5:40AM on Tuesday April 1, 2025 to 9:10AM on Tuesday April 1, 2025
	// Due to hours, customer would be charged overnight fee and there would be no compact discount
	@Test
	public void testHourlyOvernightChargeForSUVCar() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 500, new HourlyRateStrategy(new Money(500)));
					
		LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 5, 00); // Entry at 5:00AM
		LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 5, 10); // Exit at 5:10AM
		Car carSUV = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001");
					
		Money charge = lot.calculateParkingCharge(entryTime, exitTime, carSUV);
					
		assertEquals("$20.00", charge.toString());
	}
}
