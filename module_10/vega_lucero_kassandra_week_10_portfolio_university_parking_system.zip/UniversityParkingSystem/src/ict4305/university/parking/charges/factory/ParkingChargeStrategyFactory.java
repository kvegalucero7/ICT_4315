/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charges.factory;

import ict4305.university.parking.charges.strategy.ParkingChargeStrategy;
import ict4305.university.parking.charge.calculator.*;

public interface ParkingChargeStrategyFactory {
    // Updated return type is now ParkingChargeCalculator.
    ParkingChargeCalculator getStrategy(String strategyType);
}

