/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charges.strategy;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.jupiter.api.Test;

import ict4305.university.parking.Address;
import ict4305.university.parking.Car;
import ict4305.university.parking.CarType;
import ict4305.university.parking.Money;
import ict4305.university.parking.ParkingLot;


class PerEntryStrategyTest {

	// Testing per entry charge with the following scenario:
	// Parking from 9AM on Tuesday April 1, 2025 to 12:30PM on Tuesday April 1, 2025
	// Due to hours, there is a surcharge of 25% and the compact car is a 20% discount
	@Test
    public void testPerEntryChargeForCompactCar() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Base rate: 1200 cents, using a PerEntryStrategy initialized with Money(1200)
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 1200L, new PerEntryStrategy(new Money(1200)));
                
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);    // Entry at 9:00 AM
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 12, 30);   // Exit at 12:30 PM
        Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                                 CarType.COMPACT, "CI00001");
                
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
                
        assertEquals("$9.60", charge.toString());
    }
    
    @Test
    public void testPerEntryChargeForSUVCar() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Using base rate 1200 cents
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 1200L, new PerEntryStrategy(new Money(1200)));
                
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);    // Entry at 9:00 AM
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 12, 30);   // Exit at 12:30 PM
        Car carSUV = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                             CarType.SUV, "CI00001");
                        
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, carSUV);
                        
        assertEquals("$12.00", charge.toString());
    }
    
    @Test
    public void testPerEntryOvernightChargeForCompactCar() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Base rate is 1200 cents
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 1200L, new PerEntryStrategy(new Money(1200)));
                
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 5, 40);    // Entry at 5:40 AM
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 2, 9, 10);     // Exit at 9:10 AM next day
        Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                                 CarType.COMPACT, "CI00001");
                
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
                
        assertEquals("$24.60", charge.toString());
    }
    
    @Test
    public void testPerEntryOvernightChargeForSUVCar() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Base rate: 1200 cents
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 1200L, new PerEntryStrategy(new Money(1200)));
                
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 5, 40);    // Entry at 5:40 AM
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 2, 2, 10);     // Exit at 2:10 AM next day
        Car carSUV = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                             CarType.SUV, "CI00001");
                        
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, carSUV);
                        
        assertEquals("$27.00", charge.toString());
    }
    
    @Test
    public void testPerEntryChargeForCompactDuringWeekend() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Base rate: 1200 cents
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 1200L, new PerEntryStrategy(new Money(1200)));
    
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 5, 10, 0);    // Saturday entry at 10:00 AM
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 5, 14, 30);    // Exit at 2:30 PM
        Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                                 CarType.COMPACT, "CI00001");
    
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
    
        assertEquals("$7.68", charge.toString());
    }
    
    @Test
    public void testPerEntryChargeForSUVDuringWeekend() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Base rate: 1200 cents
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 1200L, new PerEntryStrategy(new Money(1200)));
    
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 5, 10, 0);    // Saturday entry at 10:00 AM
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 5, 14, 30);    // Exit at 2:30 PM
        Car carSUV = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                             CarType.SUV, "CI00001");
    
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, carSUV);
        
        assertEquals("$9.60", charge.toString());
    }
    
    @Test
    public void testPerEntryChargeOnGraduationDay() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Change base rate to 700 cents for graduation day
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 700L, new PerEntryStrategy(new Money(700)));
    
        LocalDateTime entryTime = LocalDateTime.of(2025, 5, 16, 14, 0);   // Graduation day entry at 2:00 PM
        LocalDateTime exitTime = LocalDateTime.of(2025, 5, 16, 18, 0);    // Exit at 6:00 PM
        Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                                 CarType.COMPACT, "CI00001");
    
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
    
        assertEquals("$9.10", charge.toString());
    }
    
    @Test
    public void testPerEntryChargeOnHomeComingDay() {
        Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
        // Base rate: 700 cents for homecoming day
        ParkingLot lot = new ParkingLot("PL001", address, 100, 5, 700L, new PerEntryStrategy(new Money(700)));
    
        LocalDateTime entryTime = LocalDateTime.of(2025, 10, 11, 14, 0);  // Homecoming day entry at 2:00 PM
        LocalDateTime exitTime = LocalDateTime.of(2025, 10, 11, 18, 0);   // Exit at 6:00 PM
        Car compactCar = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", 
                                 CarType.COMPACT, "CI00001");
    
        Money charge = lot.calculateParkingCharge(entryTime, exitTime, compactCar);
    
        assertEquals("$5.88", charge.toString());
    }

}