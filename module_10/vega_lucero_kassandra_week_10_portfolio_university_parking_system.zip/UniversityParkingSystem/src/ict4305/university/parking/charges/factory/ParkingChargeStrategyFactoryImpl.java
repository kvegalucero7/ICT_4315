/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charges.factory;

import ict4305.university.parking.charges.strategy.ParkingChargeStrategy;
import ict4305.university.parking.charges.strategy.HourlyRateStrategy;
import ict4305.university.parking.charges.strategy.PerEntryStrategy;
import ict4305.university.parking.Money;
import ict4305.university.parking.charge.calculator.*;

public class ParkingChargeStrategyFactoryImpl implements ParkingChargeStrategyFactory {
    @Override
    public ParkingChargeCalculator getStrategy(String strategyType) {
        switch (strategyType.toUpperCase()) {
            case "HOURLY":
                // Provide a default hourly rate of 600 cents.
                return new HourlyRateStrategy(new Money(600));
            case "PER_ENTRY":
                // Provide a default per-entry amount of 1200 cents.
                return new PerEntryStrategy(new Money(1200));
            default:
                throw new IllegalArgumentException("Strategy type unknown: " + strategyType);
        }
    }
}