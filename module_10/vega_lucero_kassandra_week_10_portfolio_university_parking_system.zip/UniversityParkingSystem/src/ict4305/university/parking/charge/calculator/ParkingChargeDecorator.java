/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import java.time.LocalDateTime;
import ict4305.university.parking.Money;
import ict4305.university.parking.Car;

//calculator for each decorator in the factory serves as the connection between decorators and the calculator
public abstract class ParkingChargeDecorator implements ParkingChargeCalculator{
	protected ParkingChargeCalculator calculator;
	
	public ParkingChargeDecorator(ParkingChargeCalculator calculator) {
		this.calculator = calculator;
	}

	@Override
	public Money calculateCharge(LocalDateTime entryTime, LocalDateTime exitTime, Car car) {
		return calculator.calculateCharge(entryTime,  exitTime, car);
	}
}
