/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import java.time.LocalDateTime;

import ict4305.university.parking.Money;
import ict4305.university.parking.Car;

public class TimeChargeDecorator extends ParkingChargeDecorator {
	public TimeChargeDecorator(ParkingChargeCalculator calculator) {
		super(calculator);
	}
	
	// adds a $4.00 fixed charge if the car enters during peak busy times
	@Override
	public Money calculateCharge(LocalDateTime entryTime, LocalDateTime exitTime, Car car) {
		Money baseCharge = super.calculateCharge(entryTime,  exitTime, car);
		//System.out.println("TIME OF DAY CHARGE charges 4.00 for hours 18 to 22");

		int entryHour = entryTime.getHour();
		Money peakHourCharge = (entryHour >= 18 && entryHour <= 22) ? new Money(400) : new Money(0);
		return baseCharge.add(peakHourCharge);
	}
}
