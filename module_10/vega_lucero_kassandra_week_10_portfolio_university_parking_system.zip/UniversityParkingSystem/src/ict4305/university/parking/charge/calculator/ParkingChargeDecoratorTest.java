/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import ict4305.university.parking.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import ict4305.university.parking.charges.strategy.*;

class ParkingChargeDecoratorTest {

	// Testing with Day charge as the only decorator
	@Test
    public void testSingleDecoratorApplication() {
        ParkingChargeCalculator baseCalculator = new HourlyRateStrategy(new Money(500)); // $5 per hour
        ParkingChargeCalculator decorator = new DayChargeDecorator(baseCalculator);

        Money charge = decorator.calculateCharge(
            LocalDateTime.of(2025, 5, 4, 10, 0),  // Sunday (Weekend)
            LocalDateTime.of(2025, 5, 4, 12, 0),
            new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(1500), charge, "Weekend charge should correctly add $5.00 charge.");
    }

	// Nested decorators
    @Test
    public void testStackedDecorators() {
        ParkingChargeCalculator baseCalculator = new HourlyRateStrategy(new Money(500)); // $5 per hour
        // day charge will be applied before compact car discount
        ParkingChargeCalculator decorator = new CarSizeChargeDecorator(new DayChargeDecorator(baseCalculator)); 

        Money charge = decorator.calculateCharge(
            LocalDateTime.of(2025, 5, 4, 10, 0),  // Sunday (Weekend)
            LocalDateTime.of(2025, 5, 4, 12, 0),
            new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(1200), charge, "Factory should apply size-based discount and weekend charge correctly.");
    }

    // Entering and exiting right away
    @Test
    public void testZeroDurationCharge() {
        ParkingChargeCalculator baseCalculator = new HourlyRateStrategy(new Money(500)); // $5 per hour
        ParkingChargeCalculator decorator = new DayChargeDecorator(baseCalculator);

        Money charge = decorator.calculateCharge(
            LocalDateTime.of(2025, 5, 4, 10, 0),  // Same entry and exit time
            LocalDateTime.of(2025, 5, 4, 10, 0),
            new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(0), charge, "Zero duration parking should result in zero charge.");
    }

    
    // Testing Exit time being before entry time
    @Test
    public void testNegativeDurationThrowsException() {
        ParkingChargeCalculator baseCalculator = new HourlyRateStrategy(new Money(500));
        ParkingChargeCalculator decorator = new DayChargeDecorator(baseCalculator);

        assertThrows(IllegalArgumentException.class, () -> {
            decorator.calculateCharge(
                LocalDateTime.of(2025, 5, 4, 12, 0), // Exit time before entry time
                LocalDateTime.of(2025, 5, 4, 10, 0),
                new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
            );
        }, "Negative parking duration should throw an exception.");
    }

    // Testing rounding up for 30 minutes
    @Test
    public void testFractionalHourCharge() {
    	
        ParkingChargeCalculator baseCalculator = new HourlyRateStrategy(new Money(500)); // $5 per hour
        ParkingChargeCalculator decorator = new DayChargeDecorator(baseCalculator);

        Money charge = decorator.calculateCharge(
            LocalDateTime.of(2025, 5, 2, 10, 0),
            LocalDateTime.of(2025, 5, 2, 10, 30), // Fractional hour parking round up for 30 min
            new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(500), charge, "Fractional hours should round up to the nearest full hour.");
    }


}
