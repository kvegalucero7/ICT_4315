/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import ict4305.university.parking.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

class DayChargeDecoratorTest {

	// Testing on a saturday. It should incur the additional $5.00
	 @Test
	 public void testWeekendChargeApplied() {
		 ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
	     ParkingChargeCalculator dayDecorator = new DayChargeDecorator(baseCalculator);

         Money charge = dayDecorator.calculateCharge(
             LocalDateTime.of(2025, 5, 3, 10, 0), // Saturday
	         LocalDateTime.of(2025, 5, 3, 12, 0),
    		 new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );
         
         assertEquals(new Money(1500), charge, "Weekend charge should add 500.");
	    }

	 // Testing on a weekday. There should be no additional charge
	 @Test
	 public void testWeekdayNoExtraCharge() {
		 ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
         ParkingChargeCalculator dayDecorator = new DayChargeDecorator(baseCalculator);

	    Money charge = dayDecorator.calculateCharge(
	    		LocalDateTime.of(2025, 5, 1, 10, 0), // Wednesday
	            LocalDateTime.of(2025, 5, 1, 12, 0),
	    		new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
	    		);
	    assertEquals(new Money(1000), charge, "Weekday should not have an extra charge.");
	    }
	 
	 //Testing Entering and exiting on weekdays that cross over a weekend
	 @Test
	 public void testFridayNightExitingOnSaturday() {
		 ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
	     ParkingChargeCalculator dayDecorator = new DayChargeDecorator(baseCalculator);
	     
	     Money charge = dayDecorator.calculateCharge(
	            LocalDateTime.of(2025, 5, 2, 23, 0), // Friday Night
	            LocalDateTime.of(2025, 5, 3, 2, 0),  // Saturday Early Morning
	    		new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
	        );

	     assertEquals(new Money(2000), charge, "Weekend charge should apply when exiting on Saturday.");
	    }
}
