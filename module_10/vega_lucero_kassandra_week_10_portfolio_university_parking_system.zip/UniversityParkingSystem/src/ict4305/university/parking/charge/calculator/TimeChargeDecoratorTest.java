/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import ict4305.university.parking.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

class TimeChargeDecoratorTest {

	// Testing charge that entry is during peak hours
	@Test
    public void testPeakHourChargeApplied() {
        ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
        ParkingChargeCalculator timeDecorator = new TimeChargeDecorator(baseCalculator);

        Money charge = timeDecorator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 18, 0), // 6 PM Peak Hour
            LocalDateTime.of(2025, 5, 1, 20, 0),
    		new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(1400), charge, "Peak hour charge should add 400.");
    }

	// Testing entry that is not during peak hours
    @Test
    public void testNoExtraChargeOutsidePeakHours() {
        ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
        ParkingChargeCalculator timeDecorator = new TimeChargeDecorator(baseCalculator);

        Money charge = timeDecorator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 12, 0), // Noon (Non-Peak)
            LocalDateTime.of(2025, 5, 1, 14, 0),
    		new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(1000), charge, "Non-peak hours should not have extra charge.");
    }

    // Testing for entry during peak hours and leaving after peak hours. Should still be charged
    @Test
    public void testEntryDuringPeakExitInOffPeak() {
        ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
        ParkingChargeCalculator timeDecorator = new TimeChargeDecorator(baseCalculator);

        Money charge = timeDecorator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 19, 0), // Peak Hour Entry
            LocalDateTime.of(2025, 5, 1, 21, 0), // Off-Peak Exit
    		new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(1400), charge, "Peak hour charge should still apply.");
    }


}
