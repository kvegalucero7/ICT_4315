/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import ict4305.university.parking.Money;
import ict4305.university.parking.Car;
import java.time.LocalDateTime;

public class BaseChargeCalculator implements ParkingChargeCalculator{
	private Money baseRate;
	
	public BaseChargeCalculator(Money baseRate) {
		this.baseRate = baseRate;
	}
	@Override
	public Money calculateCharge(LocalDateTime entryTime, LocalDateTime exitTime, Car car) {
		//System.out.println("BASE CHARGE");
		
		// Ensuring exit time is after entry time
		if (exitTime.isBefore(entryTime)) {
			throw new IllegalArgumentException("Exit time can't be before entry time");
		}
		
		// Calculating minutes parked for fractional hours
		long minutesParked = java.time.Duration.between(entryTime, exitTime).toMinutes();
		if (minutesParked < 1) {
			this.baseRate = new Money(0);
			//System.out.println("in baseCharge minutes parked: " + minutesParked);
			//System.out.println("in baseCharge charge should be 0 ");
			return baseRate.multiply(0);
		}
		
		//Calculating hours rounded up
		long hoursParked = minutesParked / 60;
		if (minutesParked % 60 > 0) {
			hoursParked++; //rounding up for left over minutes
		}
		
		return baseRate.multiply(hoursParked);
	}
}
