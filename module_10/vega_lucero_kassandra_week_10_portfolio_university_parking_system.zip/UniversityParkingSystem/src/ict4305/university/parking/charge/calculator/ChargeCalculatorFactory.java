/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import ict4305.university.parking.Money;
import ict4305.university.parking.ParkingLot;

// Reviews what factors are enabled for the parking lot to then asses the correct charges
public class ChargeCalculatorFactory {
	public static ParkingChargeCalculator createChargeCalculator(ParkingLot lot) {
		ParkingChargeCalculator calculator = new BaseChargeCalculator(new Money(lot.getBaseRate().getCents()));// converting money back to cents
		
		// checks to see if the lot offers different pricing for car type
		if (lot.isCarSizeBasedPricing()) {
			calculator = new CarSizeChargeDecorator(calculator);
		}
		// checks to see if the lot offers different pricing weekends
		if (lot.isDayRestrictedPricing()) {
			calculator = new DayChargeDecorator(calculator);
		}
		// checks to see if the lot offers different pricing during busy hours
		if (lot.isTimeRestrictedPricing()) {
			calculator = new TimeChargeDecorator(calculator);
		}
		
		return calculator;
	}
}
