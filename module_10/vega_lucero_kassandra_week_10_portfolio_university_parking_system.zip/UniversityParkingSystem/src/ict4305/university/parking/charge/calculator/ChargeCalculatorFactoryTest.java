/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import org.junit.jupiter.api.Test;
import ict4305.university.parking.Address;
import ict4305.university.parking.Car;
import ict4305.university.parking.CarType;
import ict4305.university.parking.ParkingLot;
import ict4305.university.parking.charges.strategy.HourlyRateStrategy;
import ict4305.university.parking.Money;

class ChargeCalculatorFactoryTest {

	// Testing to see if the base charge calculator is created
	@Test
	void testFactoryCreatesBaseChargeCalculator() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot(
				"PL001", 
				address, 
				100, 5, 500, // Issue to resolve in the future the base rate is coming from the parking lot and not hourly
				new HourlyRateStrategy(new Money(500)));
		
		// Setting Base
		lot.setBaseRateCents(1000); //Base rate of $10.00
		
		// other decorators are disabled
		lot.setCarSizeBasedPricing(false);
		lot.setDayRestrictedPricing(false);
		lot.setTimeRestrictedPricing(false);
		
		// Factory creates the calculator
		ParkingChargeCalculator calculator = ChargeCalculatorFactory.createChargeCalculator(lot);
		
		//calculating the charge
		Money charge = calculator.calculateCharge(
				LocalDateTime.of(2025, 5,1, 10, 0),
				LocalDateTime.of(2025,  5, 1, 12, 0),
				new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
				);
		
		//Comparing results
		assertEquals(new Money(1000), charge, "Base charge should apply correctly without decorators");
	}
	
	// Testing the creation teh calculator with no other decorators
	@Test
	public void testFactoryNoDecorators() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot(
				"PL001", 
				address, 
				100, 5, 500, // Issue to resolve in the future the base rate is coming from the parking lot and not hourly
				new HourlyRateStrategy(new Money(500)));
		
		ParkingChargeCalculator calculator = ChargeCalculatorFactory.createChargeCalculator(lot);
		
		// calculating charge using entry, exit and car
		Money charge = calculator.calculateCharge(
				LocalDateTime.of(2025, 5, 1, 12, 0),
				LocalDateTime.of(2025,  5, 1, 14, 0),
				new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
				);
		assertEquals(new Money(1000), charge, "Only base charge should be correctly applied.");
	}
	
	// Testing charge calculator while incorporating the car size consideration
	@Test
	void testFactoryAppliesCarSizeDecorator() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot(
				"PL001", 
				address, 
				100, 5, 500, // Issue to resolve in the future the base rate is coming from the parking lot and not hourly
				new HourlyRateStrategy(new Money(500)));
		
		lot.setCarSizeBasedPricing(true); // enabling car size pricing
		
		ParkingChargeCalculator calculator = ChargeCalculatorFactory.createChargeCalculator(lot);
		Money charge = calculator.calculateCharge(
				LocalDateTime.of(2025, 5,1, 10, 0),
				LocalDateTime.of(2025,  5, 1, 12, 0),
				new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001")
				);
		assertEquals(new Money(1000), charge, "SUV discount should not be applied.");
	}//1300
	
	
	// Testing using Day of week as a consideration for calculating charge
	@Test
	void testFactoryAppliesDayChargeDecorator() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot(
				"PL001", 
				address, 
				100, 5, 500, // Issue to resolve in the future the base rate is coming from the parking lot and not hourly
				new HourlyRateStrategy(new Money(500)));
		
		lot.setDayRestrictedPricing(true);
		
		ParkingChargeCalculator calculator = ChargeCalculatorFactory.createChargeCalculator(lot);
		
		Money charge = calculator.calculateCharge(
				LocalDateTime.of(2025, 5, 10, 10, 0),
				LocalDateTime.of(2025,  5, 10, 12, 0), // May 10 is a Saturday
				new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
				);
		assertEquals(new Money(1500), charge, "Weekend charge should be correctly applied.");
	}
	
	// Testing considering charges during busy time of day
	@Test
	void testFactoryAppliesTimeChargeDecorator() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot(
				"PL001", 
				address, 
				100, 5, 500, // Issue to resolve in the future the base rate is coming from the parking lot and not hourly
				new HourlyRateStrategy(new Money(500)));
		
		// enabling peak hour charges
		lot.setTimeRestrictedPricing(true);
		
		ParkingChargeCalculator calculator = ChargeCalculatorFactory.createChargeCalculator(lot);
		Money charge = calculator.calculateCharge(
				LocalDateTime.of(2025, 5,1, 18, 0),
				LocalDateTime.of(2025,  5, 1, 20, 0), // charge is assessed if during 18 to 22 
				new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
				);
		assertEquals(new Money(1400), charge, "Peak hour charge should be correctly applied.");
	}
	
	
	@Test
	void testFactoryAppliesMultupleDecorators() {
		Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot(
				"PL001", 
				address, 
				100, 5, 500, // Issue to resolve in the future the base rate is coming from the parking lot and not hourly
				new HourlyRateStrategy(new Money(500)));
		
		
		lot.setDayRestrictedPricing(true); // enabling weekend charges
		lot.setCarSizeBasedPricing(true); // enabling car size pricing
		lot.setTimeRestrictedPricing(true);// enabling peak hour charges
		
		ParkingChargeCalculator calculator = ChargeCalculatorFactory.createChargeCalculator(lot);
		Money charge = calculator.calculateCharge(
				LocalDateTime.of(2025, 5, 3, 18, 0),
				LocalDateTime.of(2025,  5, 3, 20, 0),
				new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001")
				);
		assertEquals(new Money(1900), charge, "Peak hour charge should be correctly applied.");
	}

}
