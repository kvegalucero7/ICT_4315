/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import ict4305.university.parking.*;
import java.time.LocalDate;

class BaseChargeCalculatorTest {

	@Test
    public void testStandardChargeCalculation() {
		//Creating a base charge calculator
        BaseChargeCalculator calculator = new BaseChargeCalculator(new Money(500)); // $5 per hour
        
        // indicating entry, exit and car for calculation
        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 1, 12, 0),
            new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(1000), charge, "Charge should correctly calculate for 2 hours at $5 per hour.");
    }

	// testing using lot for less than a minute
    @Test
    public void testZeroDurationCharge() {
        BaseChargeCalculator calculator = new BaseChargeCalculator(new Money(500)); // $5.00 base charge

        // indicating entry, exit and car for calculation
        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 1, 10, 0),
            new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(0), charge, "Zero duration parking should result in zero charge.");
    }

    // Testing exit time that is before entry time
    @Test
    public void testNegativeDurationThrowsException() {
        BaseChargeCalculator calculator = new BaseChargeCalculator(new Money(500));

        assertThrows(IllegalArgumentException.class, () -> {
            calculator.calculateCharge(
                LocalDateTime.of(2025, 5, 1, 12, 0), // 12 pm entry
                LocalDateTime.of(2025, 5, 1, 10, 0), // 10 am exit
                new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
            );
        }, "Negative parking duration should throw an exception.");
    }

    // Testing rounding up fractional hours
    @Test
    public void testFractionalHourCharge() {
        BaseChargeCalculator calculator = new BaseChargeCalculator(new Money(500)); // $5 per hour

        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 1, 10, 30), // only 30 minute duration
            new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );
        
        assertEquals(new Money(500), charge, "Fractional hours should round up to the nearest full hour.");
    }

    // Testing for charges that exceed 48 hrs
    @Test
    public void testMultiDayCharge() {
        BaseChargeCalculator calculator = new BaseChargeCalculator(new Money(500));

        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 4, 10, 0), // 3 days (72 hours)
   		    new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")
        );

        assertEquals(new Money(36000), charge, "Parking time should charge for all hours.");
    }


}
