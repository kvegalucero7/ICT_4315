/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.client;

/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * June 1, 2025
 * Instructor: Nathan Braun
 * 
 */	
import java.io.*;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Properties;
import org.json.JSONObject;

public class Client {
    public static void main(String[] args) {
        String hostname = "localhost";
        int port = 8080;

        try (Socket socket = new Socket(hostname, port);
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in))) {

            System.out.println("Connected to the server");

            String command;
            do {
                System.out.print("Enter command (CUSTOMER/CAR/EXIT): ");
                command = consoleReader.readLine();

                if ("CUSTOMER".equalsIgnoreCase(command)) {
                    Properties properties = new Properties();

                    System.out.print("Enter customer name: ");
                    properties.setProperty("firstname", consoleReader.readLine());

                    JSONObject jsonRequest = new JSONObject();
                    jsonRequest.put("command", command);
                    jsonRequest.put("properties", properties);

                    writer.println(jsonRequest.toString());  // Send JSON request

                } else if ("CAR".equalsIgnoreCase(command)) {
                    Properties properties = new Properties();

                    System.out.print("Enter car license plate: ");
                    properties.setProperty("license", consoleReader.readLine());

                    System.out.print("Enter customer ID: ");
                    properties.setProperty("customer", consoleReader.readLine());

                    JSONObject jsonRequest = new JSONObject();
                    jsonRequest.put("command", command);
                    jsonRequest.put("properties", properties);

                    writer.println(jsonRequest.toString());  // Send JSON request
                }

                // Read the server response
                String serverResponse;
                while ((serverResponse = reader.readLine()) != null) {
                    System.out.println("Server response: " + serverResponse);
                    break;  // Prevent infinite loops
                }

            } while (!"EXIT".equalsIgnoreCase(command));

        } catch (UnknownHostException ex) {
            System.out.println("Server not found: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("I/O error: " + ex.getMessage());
        }
    }
}

/*public class Client {
	public static void main(String[] args) {
		String hostname = "localhost";
	    int port = 8080;
	    
	    try (Socket socket = new Socket(hostname, port);
	    		OutputStream output = socket.getOutputStream();
	            PrintWriter writer = new PrintWriter(output, true);
	            InputStream input = socket.getInputStream();
	            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
	            BufferedReader consoleReader = new BufferedReader(new InputStreamReader(System.in))) { // Corrected consoleReader
	    	
	    	System.out.println("Connected to the server");
	    	String text;

	        do {
	        	System.out.print("Enter command: ");
	            text = consoleReader.readLine();

	            writer.println(text);
	            String response = reader.readLine();
	            System.out.println("Server response: " + response);
	            } while (!"EXIT".equalsIgnoreCase(text));

	        } catch (UnknownHostException ex) {
	            System.out.println("Server not found: " + ex.getMessage());
	        } catch (IOException ex) {
	            System.out.println("I/O error: " + ex.getMessage());
	        }
	    }
	}
	*/
