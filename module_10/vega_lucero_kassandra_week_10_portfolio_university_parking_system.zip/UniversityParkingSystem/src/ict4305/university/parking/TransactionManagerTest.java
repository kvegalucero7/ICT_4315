/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.time.LocalDateTime;
import ict4305.university.parking.charges.strategy.HourlyRateStrategy;
import ict4305.university.parking.charges.strategy.*;
import java.time.LocalDate;
import ict4305.university.parking.charge.calculator.*;


class TransactionManagerTest {
	
	@Test
    public void testPostTransactionSuccessfully() {
        // Initial set up
        Address address = new Address("987 Central Ave", null, "Denver", "CO", "80204");
        
        // Create a ParkingChargeCalculator to be used by both ParkingLot and TransactionManager.
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
        
        // Note: base rate is provided as a long (600L)
        ParkingLot parkingLot = new ParkingLot("Lot1", address, 100, 0, 600L, calculator);
        
        // Use the same calculator in TransactionManager
        TransactionManager transactionManager = new TransactionManager(calculator);
        
        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 11, 30);
        
        // Posting the transaction
        transactionManager.postTransaction(parkingLot, entryTime, exitTime, car);
        
        // Expect exactly one transaction recorded
        assertEquals(1, transactionManager.getTransactions().size(), "Transaction should be recorded.");
    }

	
	@Test
    public void testChargeCalculationForSingleTransaction() {
        // Initial set up
        Address address = new Address("987 Central Ave", null, "Denver", "CO", "80204");
        
        // Create an instance of ParkingChargeCalculator using HourlyRateStrategy (600 cents per hour).
        // Note: Passing a Money object representing the rate.
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
        
        // Construct the parking lot with a base rate as a long (600L) and the calculator
        ParkingLot parkingLot = new ParkingLot("Lot1", address, 100, 0, 600L, calculator);
        
        // Create the TransactionManager using the same calculator instance.
        TransactionManager transactionManager = new TransactionManager(calculator);
        
        // Set up a car and entry/exit times.
        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);
        LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 11, 30);
        
        // Record a single transaction.
        transactionManager.postTransaction(parkingLot, entryTime, exitTime, car);
        
        // Calculate the expected charge using the same calculator.
        Money expectedCharge = calculator.calculateCharge(entryTime, exitTime, car);
        
        // Verify that the total charges recorded in the TransactionManager match the expected value.
        assertEquals(expectedCharge, transactionManager.calculateCharges(), 
                     "Charge should match expected calculation.");
    }



		/*// initial set up
		ParkingLot parkingLot = new ParkingLot("Lot1", new Address("987 Central Ave", null, "Denver", "CO", "80204"), 100, 0, 
				600, new HourlyRateStrategy(new Money(600)));
		TransactionManager transactionManager = new TransactionManager();
		Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
		LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);
		LocalDateTime exitTime = LocalDateTime.of(2025, 4, 1, 11, 30);
		
		// recording a single transaction
		transactionManager.postTransaction(parkingLot, entryTime, exitTime, car);
		
		//setting up expected value
		//Money expectedCharge = new HourlyRateStrategy().calculateCharge(new Money(600), entryTime, exitTime, car);
		HourlyRateStrategy strategy = new HourlyRateStrategy(new Money(600));
		Money expectedCharge = strategy.calculateCharge(new Money(600), entryTime, exitTime, car);
		
		//testing expected against actual
		assertEquals(expectedCharge, transactionManager.calculateCharges(), "Charge shouldmatch expected calculation.");*/
	
	@Test
    public void testCustomerChargeCalculation() {
        // Initial set up:
        Address lotAddress = new Address("987 Central Ave", null, "Denver", "CO", "80204");
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
        ParkingLot parkingLot = new ParkingLot("Lot1", lotAddress, 100, 0, 600L, calculator);
        
        // Create TransactionManager with the provided calculator.
        TransactionManager transactionManager = new TransactionManager(calculator);
        
        // Set up customer vehicle and times.
        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
        LocalDateTime firstEntryTime = LocalDateTime.of(2025, 4, 1, 9, 0);
        LocalDateTime firstExitTime  = LocalDateTime.of(2025, 4, 1, 11, 30);
        
        // Create the first transaction.
        transactionManager.postTransaction(parkingLot, firstEntryTime, firstExitTime, car);
        
        // Create a second transaction.
        LocalDateTime secondEntryTime = LocalDateTime.of(2025, 4, 2, 9, 0);
        LocalDateTime secondExitTime  = LocalDateTime.of(2025, 4, 2, 11, 30);
        transactionManager.postTransaction(parkingLot, secondEntryTime, secondExitTime, car);


        // Calculate the expected charge using the same calculator.
        Money expectedCharge = new Money(0);
        expectedCharge = expectedCharge.add(calculator.calculateCharge(firstEntryTime, firstExitTime, car));
        expectedCharge = expectedCharge.add(calculator.calculateCharge(secondEntryTime, secondExitTime, car));


        // Prepare the customer (assuming the charge for the customer is retrieved by matching the car's identifier).
        Customer customer = new Customer("CI0005", "Johnny Smith", 
                                         new Address("998 A Street", null, "Denver", "CO", "80204"), 
                                         "1235551234");


        // Compare the expected total with what is calculated for the customer.
        // (Assuming TransactionManager has a method calculateChargeForCustomer based on customer data.)
        assertEquals(expectedCharge, transactionManager.calculateChargeForCustomer(customer),
                "Charge should match customer's total.");
    }


    @Test
    public void testEqualsAndHashCodeForTransactionManager() {
        // Set up the common objects.
        Address lotAddress = new Address("987 Central Ave", null, "Denver", "CO", "80204");
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
        ParkingLot parkingLot = new ParkingLot("Lot1", lotAddress, 100, 0, 600L, calculator);
        
        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);
        LocalDateTime exitTime  = LocalDateTime.of(2025, 4, 1, 11, 30);


        // Create the first TransactionManager and post a transaction.
        TransactionManager transactionManager1 = new TransactionManager(calculator);
        transactionManager1.postTransaction(parkingLot, entryTime, exitTime, car);


        // Create a duplicate TransactionManager with identical transaction(s).
        TransactionManager transactionManager2 = new TransactionManager(calculator);
        transactionManager2.postTransaction(parkingLot, entryTime, exitTime, car);


        // Test equality and hash code.
        assertEquals(transactionManager1, transactionManager2,
            "Transaction Managers with the same values should be equal.");
        assertEquals(transactionManager1.hashCode(), transactionManager2.hashCode(),
            "Hash codes should match.");
    }


    @Test
    public void testInvalidTransactionThrowsException() {
        Address lotAddress = new Address("987 Central Ave", null, "Denver", "CO", "80204");
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
        ParkingLot parkingLot = new ParkingLot("Lot1", lotAddress, 100, 0, 600L, calculator);
        TransactionManager transactionManager = new TransactionManager(calculator);
        
        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
        LocalDateTime entryTime = LocalDateTime.of(2025, 4, 1, 9, 0);
        LocalDateTime exitTime  = LocalDateTime.of(2025, 4, 1, 11, 30);


        // Passing null parkingLot
        assertThrows(IllegalArgumentException.class,
            () -> transactionManager.postTransaction(null, entryTime, exitTime, car),
            "Null parking lot should throw IllegalArgumentException.");


        // Passing null entryTime
        assertThrows(IllegalArgumentException.class,
            () -> transactionManager.postTransaction(parkingLot, null, exitTime, car),
            "Null entry time should throw IllegalArgumentException.");


        // Passing null exitTime
        assertThrows(IllegalArgumentException.class,
            () -> transactionManager.postTransaction(parkingLot, entryTime, null, car),
            "Null exit time should throw IllegalArgumentException.");


        // Passing null car
        assertThrows(IllegalArgumentException.class,
            () -> transactionManager.postTransaction(parkingLot, entryTime, exitTime, null),
            "Null car should throw IllegalArgumentException.");
    }

}
