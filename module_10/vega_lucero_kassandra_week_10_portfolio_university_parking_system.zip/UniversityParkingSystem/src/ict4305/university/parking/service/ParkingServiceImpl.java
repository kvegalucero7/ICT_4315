package ict4305.university.parking.service;

public class ParkingServiceImpl implements ParkingService {
	@Override
	public void registerCustomer(String name) {
		System.out.println("Customer registered: " + name);
	}
	
	@Override
	public void assignParkingSpot(String license, String customerId) {
		System.out.println("Assigned car: " + license + " to customer " + customerId);
	}
}
