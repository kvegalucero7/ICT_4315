package ict4305.university.parking.service;

public class ParkingValidator {
	public static boolean isValidLicense(String license) {
		return license.matches("[A-Z0-9]{1,7}"); // regex set for letters and numbers
	}
}
