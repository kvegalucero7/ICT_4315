package ict4305.university.parking.service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import ict4305.university.parking.service.ParkingValidator;


class ParkingValidatorTest {


    @Test
    public void testValidLicensePlate() {
        assertEquals(true, ParkingValidator.isValidLicense("ABC123"));
        assertEquals(true, ParkingValidator.isValidLicense("XYZ789"));
    }


    @Test
    public void testInvalidLicensePlate() {
        assertEquals(false, ParkingValidator.isValidLicense(""));
        assertEquals(false, ParkingValidator.isValidLicense("INVALID123456"));
        assertEquals(false, ParkingValidator.isValidLicense("!!!"));
    }
}

