package ict4305.university.parking.service;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ict4305.university.parking.service.ParkingService;
import ict4305.university.parking.service.ParkingServiceImpl;

class ParkingServiceImplTest {
    private ParkingService parkingService;


    @BeforeEach
    public void setUp() {
        parkingService = new ParkingServiceImpl();
    }


    @Test
    public void testRegisterCustomer() {
        assertDoesNotThrow(() -> parkingService.registerCustomer("John Doe"));
    }


    @Test
    public void testAssignParkingSpot() {
        assertDoesNotThrow(() -> parkingService.assignParkingSpot("ABC123", "CUST1"));
    }
}

