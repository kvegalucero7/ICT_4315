package ict4305.university.parking.service;

public interface ParkingService {
	void registerCustomer(String name);
	void assignParkingSpot(String licensePlate, String customerId);
}
