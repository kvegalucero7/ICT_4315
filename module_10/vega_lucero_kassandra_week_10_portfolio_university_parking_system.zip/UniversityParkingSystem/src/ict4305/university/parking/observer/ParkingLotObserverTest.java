/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.observer;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import ict4305.university.parking.*;
import ict4305.university.parking.charges.strategy.HourlyRateStrategy;
import ict4305.university.parking.events.ParkingEvent;
import ict4305.university.parking.charge.calculator.*;

class ParkingLotObserverTest {

	@Test
    public void testObserverHandlesExitEvent() {
        // Create a calculator instance (HourlyRateStrategy implements ParkingChargeCalculator)
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
        
        // Create a TransactionManager using the calculator instance
        TransactionManager transactionManager = new TransactionManager(calculator);
        
        // Create the observer with the TransactionManager reference
        ParkingLotObserver observer = new ParkingLotObserver(transactionManager);
        
        // Create a Car and associated ParkingPermit
        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
        ParkingPermit permit = new ParkingPermit(car);
        
        // Construct a ParkingLot, setting currentUse to 1 and passing the same calculator.
        // Note: The base rate is passed as a long (600L).
        ParkingLot parkingLot = new ParkingLot("Lot1",
                new Address("987 Central Ave", null, "Denver", "CO", "80204"),
                100, 1, 600L, calculator);
        
        // Record initial capacity.
        int initialUsage = parkingLot.getCurrentUse();
        
        // Create an exit event (false indicates an exit event).
        LocalDateTime timestamp = LocalDateTime.now();
        ParkingEvent exitEvent = new ParkingEvent(timestamp, permit, parkingLot, false);
        
        // The observer processes the exit event.
        observer.update(exitEvent);
        
        // After processing, the parking lot's current usage should have decreased by 1.
        assertEquals(initialUsage - 1, parkingLot.getCurrentUse(), 
                "Parking lot usage should decrease when a car exits.");
        
        // A transaction should also be recorded as a result of the exit event.
        assertEquals(1, transactionManager.getTransactions().size(), 
                "Transaction should be recorded after an exit.");
    }

	
	 @Test
	    public void testObserverHandlesEntryEvent() {
	        // Set up the shared calculator to be used by TransactionManager and ParkingLot
	        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
	        TransactionManager transactionManager = new TransactionManager(calculator);
	        ParkingLotObserver observer = new ParkingLotObserver(transactionManager);
	        
	        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
	        ParkingPermit permit = new ParkingPermit(car);
	        ParkingLot parkingLot = new ParkingLot("Lot1",
	                new Address("987 Central Ave", null, "Denver", "CO", "80204"),
	                100, 0, 600L, calculator);
	        LocalDateTime timestamp = LocalDateTime.now();


	        // Record the initial parking lot usage
	        int initialUsage = parkingLot.getCurrentUse();
	        
	        // Create an entry event (true indicates entry)
	        ParkingEvent entryEvent = new ParkingEvent(timestamp, permit, parkingLot, true);
	        
	        // Directly update the observer with the entry event
	        observer.update(entryEvent);
	        
	        // The parking lot's current usage should increase by 1 (observer notifies update)
	        assertEquals(initialUsage + 1, parkingLot.getCurrentUse(),
	                "Parking lot usage should increase when a car goes in.");
	        // Entry events should not trigger posting a transaction
	        assertEquals(0, transactionManager.getTransactions().size(),
	                "Entry event should not trigger a transaction.");
	    }
	    
	    @Test
	    public void testObserveIgnoresEntryEvent() {
	        // Set up the shared calculator for consistency.
	        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
	        TransactionManager transactionManager = new TransactionManager(calculator);
	        ParkingLotObserver observer = new ParkingLotObserver(transactionManager);
	        
	        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
	        ParkingPermit permit = new ParkingPermit(car);
	        ParkingLot parkingLot = new ParkingLot("Lot1",
	                new Address("987 Central Ave", null, "Denver", "CO", "80204"),
	                100, 0, 600L, calculator);
	        LocalDateTime timestamp = LocalDateTime.now();
	        
	        // Create an entry event
	        ParkingEvent entryEvent = new ParkingEvent(timestamp, permit, parkingLot, true);
	        
	        // Process the event via the observer
	        observer.update(entryEvent);
	        
	        // Entry events should not create a transaction.
	        assertEquals(0, transactionManager.getTransactions().size(),
	                "Entry event should not trigger a transaction.");
	    }
	    
	    @Test
	    public void testAddObserveReceivesUpdates() {
	        // Set up the shared calculator
	        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
	        ParkingLot parkingLot = new ParkingLot("Lot1",
	                new Address("987 Central Ave", null, "Denver", "CO", "80204"),
	                100, 0, 600L, calculator);
	        TransactionManager transactionManager = new TransactionManager(calculator);
	        ParkingLotObserver observer = new ParkingLotObserver(transactionManager);
	        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
	        LocalDateTime timestamp = LocalDateTime.now();


	        // Add the observer to the parking lot so it will receive update notifications
	        parkingLot.addObserver(observer);
	        ParkingPermit permit = new ParkingPermit(car);
	        ParkingEvent entryEvent = new ParkingEvent(timestamp, permit, parkingLot, true);
	        
	        // Simulate an event notification (should trigger observer.update internally)
	        parkingLot.notifyObservers(entryEvent);
	        
	        // Upon notification, current usage should increase by 1
	        assertEquals(1, parkingLot.getCurrentUse(),
	                "Lot usage should increase when notified of entry.");
	    }
	    
	    @Test
	    public void testRemoveObserveStopUpdates() {
	        // Set up shared components
	        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(600));
	        ParkingLot parkingLot = new ParkingLot("Lot1",
	                new Address("987 Central Ave", null, "Denver", "CO", "80204"),
	                100, 0, 600L, calculator);
	        TransactionManager transactionManager = new TransactionManager(calculator);
	        ParkingLotObserver observer = new ParkingLotObserver(transactionManager);
	        Car car = new Car("Permit 1234", LocalDate.now().plusYears(1), "ABC123", CarType.COMPACT, "CI0005");
	        LocalDateTime timestamp = LocalDateTime.now();
	        
	        // Add and then remove the observer from the parking lot
	        parkingLot.addObserver(observer);
	        parkingLot.removeObserver(observer);
	        
	        ParkingPermit permit = new ParkingPermit(car);
	        ParkingEvent exitEvent = new ParkingEvent(timestamp, permit, parkingLot, false);
	        
	        // Notify observers; since our observer was removed, no update should occur.
	        parkingLot.notifyObservers(exitEvent);
	        
	        // No transaction should have been recorded since the observer is no longer listening.
	        assertEquals(0, transactionManager.getTransactions().size(),
	                "Transaction should not be recorded after observer removal.");
	    }


}
