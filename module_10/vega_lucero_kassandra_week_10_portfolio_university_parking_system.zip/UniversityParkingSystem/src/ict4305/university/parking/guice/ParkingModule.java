/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.guice;

import com.google.inject.AbstractModule;
import ict4305.university.parking.service.ParkingService;
import ict4305.university.parking.service.ParkingServiceImpl;

public class ParkingModule extends AbstractModule{
	@Override
	protected void configure() {
		bind(ParkingService.class).to(ParkingServiceImpl.class);
		
	}

}
