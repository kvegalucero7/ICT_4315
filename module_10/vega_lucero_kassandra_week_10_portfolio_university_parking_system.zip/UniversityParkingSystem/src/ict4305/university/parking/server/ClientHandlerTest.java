/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.server;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.io.*;
import java.net.Socket;
import java.util.Properties;

import org.json.JSONObject;
import ict4305.university.parking.server.ClientHandler;
import ict4305.university.parking.service.ParkingService;
import ict4305.university.parking.service.ParkingServiceImpl;
import ict4305.university.parking.server.client.helpers.*;



class ClientHandlerTest {
    private ParkingService parkingService;
    private ClientHandler clientHandler;

    @BeforeEach
    public void setUp() throws IOException {
        // Create the ParkingService implementation.
        parkingService = new ParkingServiceImpl();


        // Create a dummy socket. 
        // Optionally, you could use a mocking framework or a stub if your service depends on specific socket behavior.
        Socket dummySocket = new Socket("localhost", 8080);


        // Create the ClientHandler with the ParkingService and socket.
        clientHandler = new ClientHandler(parkingService, dummySocket);
    }


    @Test
    public void testProcessCustomerRequest() {
        // Prepare properties for a CUSTOMER request.
        Properties props = new Properties();
        props.setProperty("firstname", "John");


        ParkingRequest request = new ParkingRequest("CUSTOMER", props);
        ParkingResponse response = clientHandler.processRequest(request);


        // Check response status and message.
        assertEquals(200, response.getStatusCode(), "Expected status code 200 for a valid customer registration.");
        assertEquals("Customer registered: John", response.getMessage(), "Expected registered message for John.");
    }


    @Test
    public void testProcessCarRequest() {
        // Prepare properties for a CAR request.
        Properties props = new Properties();
        props.setProperty("license", "ABC123");
        props.setProperty("customer", "CUST1");


        ParkingRequest request = new ParkingRequest("CAR", props);
        ParkingResponse response = clientHandler.processRequest(request);


        // Check response status and message.
        assertEquals(200, response.getStatusCode(), "Expected status code 200 for a valid car assignment.");
        assertEquals("Car assigned: ABC123 to customer CUST1", response.getMessage(), "Expected car assignment confirmation.");
    }


    @Test
    public void testProcessUnknownCommand() {
        // Prepare an empty or unrecognized command.
        Properties props = new Properties();
        ParkingRequest request = new ParkingRequest("UNKNOWN", props);
        ParkingResponse response = clientHandler.processRequest(request);


        // Check that an unknown command yields a 400 error and appropriate message.
        assertEquals(400, response.getStatusCode(), "Expected status code 400 for an unknown command.");
        assertEquals("Error: Unknown command.", response.getMessage(), "Expected error message for an unknown command.");
    }
}

