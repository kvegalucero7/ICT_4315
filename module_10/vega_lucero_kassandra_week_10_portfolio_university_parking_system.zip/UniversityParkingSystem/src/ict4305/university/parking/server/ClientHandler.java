/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 10 University Parking System Portfolio
 *      (Continuation of ICT 4305)
 * June 8, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.server;

import java.io.*;
import java.net.*;
import java.util.Properties;

import org.json.JSONObject;

import ict4305.university.parking.server.client.helpers.*;
import com.google.inject.Inject;
import ict4305.university.parking.service.ParkingService;

class ClientHandler implements Runnable {
    private Socket socket;
	private final ParkingService parkingService;
	
	@Inject
	public ClientHandler(ParkingService parkingService, Socket socket) {
		this.parkingService = parkingService;
		this.socket =  socket;
	}
	
	public void setSocket(Socket socket) {
		
	}

    @Override
    public void run() {
    	if (socket == null) {
    		System.out.println("Socket is null. Can't continue.");
    		return;
    	}
    	
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

        	// This should serve as an initial indicator that the server is working
            writer.println("Welcome to the Parking System! Please enter a command (CUSTOMER, CAR, EXIT):");

            String jsonMessage;
            while ((jsonMessage = reader.readLine()) != null) {
                System.out.println("Received JSON: " + jsonMessage);
                
                // convert string to JSONObject before processing
                JSONObject jsonObject = new JSONObject(jsonMessage);
                
                // convert JSONObject to ParkingRequest before passing to processRequest()
                ParkingRequest request = ParkingRequest.fromJson(jsonObject);
                
                writer.println("Processing request...");

                //call processRequest with correct type
                ParkingResponse response = processRequest(request);
                
                //Send JSON response back to the client
                writer.println(response.toJson());
                
                
                /// OMitting for now
                /*writer.println(response.toJson());  // Send JSON response
                
                // Send another prompt after responding
                writer.println("Enter another command or type EXIT to quit:");*/
            }

        } catch (IOException ex) {
            System.out.println("Client error: " + ex.getMessage());
            ex.printStackTrace();
        }
        
    }

    ParkingResponse processRequest(ParkingRequest request) {
        String command = request.getCommand();
        Properties props = request.getProperties();


        switch (command) {
            case "CUSTOMER":
                String customerName = props.getProperty("firstname");
                if (customerName == null || customerName.isEmpty()) {
                    return new ParkingResponse(400, "Error: Customer name cannot be empty.");
                }
                parkingService.registerCustomer(customerName);
                return new ParkingResponse(200, "Customer registered: " + customerName);


            case "CAR":
                String licensePlate = props.getProperty("license");
                String customerId = props.getProperty("customer");
                if (licensePlate == null || licensePlate.isEmpty() || customerId == null || customerId.isEmpty()) {
                    return new ParkingResponse(400, "Error: License plate and customer ID required.");
                }
                parkingService.assignParkingSpot(licensePlate, customerId);
                return new ParkingResponse(200, "Car assigned: " + licensePlate + " to customer " + customerId);


            default:
                return new ParkingResponse(400, "Error: Unknown command.");
        }
    }

}
