/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * June 1, 2025
 * Instructor: Nathan Braun
 * 
 */	
package ict4305.university.parking.server;

import java.io.*;
import java.net.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
//import com.google.inject.Inject;
import com.google.inject.Guice;
import com.google.inject.Injector;
//import com.google.inject.AbstractModule;
import ict4305.university.parking.guice.ParkingModule;


public class Server {
    private static final int PORT = 8080;
    private static final int MAX_THREADS = 10;
    private static final ExecutorService threadPool = Executors.newFixedThreadPool(MAX_THREADS);


    public static void main(String[] args) {
        // Create injector to manage dependencies
        Injector injector = Guice.createInjector(new ParkingModule());


        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening on port " + PORT);


            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("New client connected.");

                // Instead of manually creating ClientHandler, use Guice to inject dependencies
                ClientHandler handler = injector.getInstance(ClientHandler.class);
                
                // injecting the socket seperately
                handler.setSocket(socket); 
                
                // executing the handler in a separate thread
                threadPool.execute(handler);
            }
        } catch (IOException ex) {
            System.out.println("Server exception: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}

