package ict4305.university.parking.server;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.IOException;
import java.net.ServerSocket;


class ServerTest {


    @Test
    public void testServerStartsSuccessfully() {
        assertDoesNotThrow(() -> {
            try (ServerSocket serverSocket = new ServerSocket(8080)) {
                assertEquals(true, serverSocket.isBound());
            }
        });
    }
}

