package ict4305.university.parking.server.client.helpers;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.json.JSONObject;
//import ict4305.university.parking.server.client.helpers.ParkingRequest;
import java.util.Properties;

public class ParkingRequestTest {

	@Test
	public void testSerialization() {
		Properties properties = new Properties();
		properties.setProperty("firstname", "Rob");
		
		ParkingRequest request = new ParkingRequest("CUSTOMER", properties);
		String json = request.toJson();
		
		JSONObject jsonObj = new JSONObject(json);
		assertEquals("CUSTOMER", jsonObj.getString("command"));
		assertEquals("Rob", jsonObj.getJSONObject("properties").getString("firstname"));
	}
	
	@Test
	public void testDeserialization() {
		String json = "{\"command\":\"CUSTOMER\",\"properties\":{\"firstname\":\"Rob\"}}";
		ParkingRequest request = ParkingRequest.fromJson(new JSONObject(json));
		
		assertEquals("CUSTOMER", request.getCommand());
		assertEquals("Rob", request.getProperties().getProperty("firstname"));
	}
}
