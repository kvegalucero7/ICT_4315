package ict4305.university.parking.server.client.helpers;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import org.json.JSONObject;
//import ict4305.university.parking.server.client.helpers.*;


class ParkingResponseTest {


    @Test
    void testSerialization() {
        ParkingResponse response = new ParkingResponse(200, "Success");
        String json = response.toJson();


        // Verify JSON content
        JSONObject jsonObj = new JSONObject(json);
        assertEquals(200, jsonObj.getInt("statusCode"));
        assertEquals("Success", jsonObj.getString("message"));
    }


    @Test
    void testDeserialization() {
        String json = "{\"statusCode\":200,\"message\":\"Success\"}";
        ParkingResponse response = ParkingResponse.fromJson(new JSONObject(json));


        // Verify object properties after deserialization
        assertEquals(200, response.getStatusCode());
        assertEquals("Success", response.getMessage());
    }
}
