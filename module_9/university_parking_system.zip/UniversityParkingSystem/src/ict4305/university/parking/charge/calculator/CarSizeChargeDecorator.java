/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * May 11, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import ict4305.university.parking.Car;
import ict4305.university.parking.CarType;
import ict4305.university.parking.Money;
import java.time.LocalDateTime;

public class CarSizeChargeDecorator extends ParkingChargeDecorator{
	private double compactDiscount = 0.80; //20% off for compact
	
	public CarSizeChargeDecorator(ParkingChargeCalculator calculator) {
		super(calculator);
	}
	
	@Override 
	public Money calculateCharge(LocalDateTime entryTime, LocalDateTime exitTime, Car car) {
		Money baseCharge = super.calculateCharge(entryTime,  exitTime, car);
		//System.out.println("CAR Size CHARGE");

		// checking if compact and multiplying for the discount
		if (car.getCarType() == CarType.COMPACT) {
			return baseCharge.multiply(compactDiscount);
		}
		return baseCharge;
	}
}
