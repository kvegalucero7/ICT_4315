/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * June 1, 2025
 * Instructor: Nathan Braun
 * 
 */	
package ict4305.university.parking.server.client.helpers;

import org.json.JSONObject;

public class ParkingResponse {
    private int statusCode;
    private String message;

    public ParkingResponse(int statusCode, String message) {
        this.statusCode = statusCode;
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    // Converting a ParkingResponse to a JSON String
    public String toJson() {
        JSONObject json = new JSONObject();
        json.put("statusCode", statusCode);
        json.put("message", message);
        return json.toString();
    }

    // Converting a JSON Object to ParkingResponse
    public static ParkingResponse fromJson(JSONObject json) {
        return new ParkingResponse(json.getInt("statusCode"), json.getString("message"));
    }
}