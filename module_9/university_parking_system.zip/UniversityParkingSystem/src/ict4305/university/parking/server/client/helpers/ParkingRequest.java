/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * June 1, 2025
 * Instructor: Nathan Braun
 * 
 */	
package ict4305.university.parking.server.client.helpers;

import java.util.Properties;
import org.json.JSONObject;

public class ParkingRequest {
    private String command;
    private Properties properties;

    public ParkingRequest(String command, Properties properties) {
        this.command = command;
        this.properties = properties;
    }

    public String getCommand() {
        return command;
    }

    public Properties getProperties() {
        return properties;
    }

    // Converting a ParkingRequest to JSON String
    public String toJson() {
        JSONObject json = new JSONObject();
        json.put("command", command);

        JSONObject propsJson = new JSONObject();
        properties.forEach((key, value) -> propsJson.put((String) key, value));

        json.put("properties", propsJson);
        return json.toString();
    }

    // Converting a JSON Object to ParkingRequest
    public static ParkingRequest fromJson(JSONObject json) {
        String command = json.getString("command");

        Properties props = new Properties();
        JSONObject propsJson = json.getJSONObject("properties");
        propsJson.keySet().forEach(key -> props.setProperty(key, propsJson.getString(key)));

        return new ParkingRequest(command, props);
    }
}