/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * June 1, 2025
 * Instructor: Nathan Braun
 * 
 */	
package ict4305.university.parking.server;

import java.io.*;
import java.net.*;
import ict4305.university.parking.server.client.helpers.*;

class ClientHandler implements Runnable {
    private Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
             PrintWriter writer = new PrintWriter(socket.getOutputStream(), true)) {

        	// This should serve as an initial indicator that the server is working
            writer.println("Welcome to the Parking System! Please enter a command (CUSTOMER, CAR, EXIT):");

            String jsonMessage;
            while ((jsonMessage = reader.readLine()) != null) {
                System.out.println("Received JSON: " + jsonMessage);

                //this stopped working after I added the prompts for the other command components
                ParkingRequest request = ParkingRequest.fromJson(jsonMessage);
                ParkingResponse response = processRequest(request);

                writer.println(response.toJson());  // Send JSON response
                
                // Send another prompt after responding
                writer.println("Enter another command or type EXIT to quit:");
            }

        } catch (IOException ex) {
            System.out.println("Client error: " + ex.getMessage());
            ex.printStackTrace();
        }
        
    }

    private ParkingResponse processRequest(ParkingRequest request) {
        if ("CUSTOMER".equals(request.getCommand())) {
            return new ParkingResponse(200, "Customer registered: " + request.getProperties().getProperty("firstname"));
        } else if ("CAR".equals(request.getCommand())) {
            return new ParkingResponse(200, "Car assigned: " + request.getProperties().getProperty("license"));
        } else {
            return new ParkingResponse(400, "Unknown command.");
        }
    }
}
