/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * May 11, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import java.time.LocalDateTime;
import ict4305.university.parking.Money;
import ict4305.university.parking.Car;

// Calculator for all of the decorators gets overridden
public interface ParkingChargeCalculator {
	Money calculateCharge(LocalDateTime entryTime, LocalDateTime exitTime, Car car);
}
