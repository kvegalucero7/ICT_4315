/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 *      May 25, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.parking.clients;

import ict4305.parking.server.ParkingRequest;
import ict4305.parking.server.ParkingResponse;
import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;

public class ServerClient {
    public static void main(String[] args) {
    	// checking to see if at least one command name was included and one parameter
        if (args.length < 2) {
            System.out.println("Usage: java ServerClient <COMMAND> <PARAMS>");
            return;
        }

        // the first entry will be the command
        String command = args[0];
        
        // A map is used to store other parameters and will be used elsewhere
        Map<String, String> parameters = new HashMap<>();

        // a loop is used to go through and verify valid key value entries while splitting at the "="
        for (int i = 1; i < args.length; i++) {
            String[] kv = args[i].split("=");
            if (kv.length == 2) parameters.put(kv[0], kv[1]);
        }

        // new request is created using information extracted
        ParkingRequest request = new ParkingRequest(command, parameters);
        sendRequest(request);
    }

    private static void sendRequest(ParkingRequest request) {
    	// try is used again to make sure it closes after being used and uses indicated port "8080"
        try (Socket socket = new Socket("localhost", 8080);
        		
             //Sends data over the port
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
        		
        	 // creating a reader to read server's response
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {

        	// turning  ParkingRequest object to a JSON string
            out.println(request.toJson());
            
            // reading a single line response
            String jsonResponse = in.readLine();
            
            // Turning String back to an object
            ParkingResponse response = ParkingResponse.fromJson(jsonResponse);

            // printing the response for understanding
            System.out.println("Server Response: " + response);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

/*import ict4305.parking.server.ParkingRequest;
import ict4305.parking.server.ParkingResponse;
import java.io.*;
import java.net.*;
import java.util.Properties;

public class ServerClient {
    public static void main(String[] args) {
        if (args.length < 2) {
            System.out.println("Usage: java ServerClient <COMMAND> <PARAMS>");
            return;
        }

        String command = args[0];
        Properties properties = new Properties();
        
        for (int i = 1; i < args.length; i++) {
            String[] kv = args[i].split("=");
            if (kv.length == 2) properties.setProperty(kv[0], kv[1]);
        }

        ParkingRequest request = new ParkingRequest(command, properties);
        sendRequest(request);
    }

    private static void sendRequest(ParkingRequest request) {
        try (Socket socket = new Socket("localhost", 8080);
             PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
             BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()))) {
            
            out.println(request.toJson());
            String jsonResponse = in.readLine();
            ParkingResponse response = ParkingResponse.fromJson(jsonResponse);
            
            System.out.println("Server Response: " + response);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}*/
