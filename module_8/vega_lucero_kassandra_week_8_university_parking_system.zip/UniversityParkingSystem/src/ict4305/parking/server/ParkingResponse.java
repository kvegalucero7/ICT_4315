/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 *      May 25, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.parking.server;

public class ParkingResponse {
    //Christian indicated the statusCode was needed but I am not too sure why
    private int statusCode;
    private String message;// to store message with more details

    // create a new parking response and assigns values
    public ParkingResponse(int statusCode, String message) {
        this.statusCode = statusCode;
        this.message = message;
    }

    // Getters for values assigned in the parking response
    public int getStatusCode() {
        return statusCode;
    }
    
    public String getMessage() {
        return message;
    }

    
    // Turns response to JSON manually
    public String toJson() {
        return "{\"statusCode\":" + statusCode + ",\"message\":\"" + message + "\"}";
    }

    
    // Convert JSON string back to object manually
    public static ParkingResponse fromJson(String json) {
    	// expects string to be formatted the same as the toJson string
    	// removes curly braces ({}), and any double quotes
        json = json.replace("{", "").replace("}", "").replace("\"", "");
        
        // splitting the string at the comma to get the key-value pairs
        String[] parts = json.split(",");
        
        // splitting at the colon to get the individual value entries
        int statusCode = Integer.parseInt(parts[0].split(":")[1]);
        
        // also splitting at the colon to get the individual value entries
        String message = parts[1].split(":")[1];

        return new ParkingResponse(statusCode, message);
    }
}
/*import com.google.gson.*;

public class ParkingResponse {
    private int statusCode;
    private String message;

    public ParkingResponse(int statusCode, String message) {
        this.statusCode = statusCode;
        this.message = message;
    }

    public int getStatusCode() {
        return statusCode;
    }

    public String getMessage() {
        return message;
    }

    public String toJson() {
        return new Gson().toJson(this);
    }

    public static ParkingResponse fromJson(String json) {
        return new Gson().fromJson(json, ParkingResponse.class);
    }

    @Override
    public String toString() {
        return "Status: " + statusCode + ", Message: " + message;
    }
}*/