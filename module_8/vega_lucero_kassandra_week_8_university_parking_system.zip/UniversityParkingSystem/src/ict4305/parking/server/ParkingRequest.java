/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 *      May 25, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.parking.server;

import java.util.HashMap;
import java.util.Map;
//import org.json.JSONObject;


public class ParkingRequest {
    private String commandName; //command name for request in question
    private Map<String, String> parameters; //entries are key value pairs for the commnds

    //assigning values to variables based on constructor paarmeters
    public ParkingRequest(String commandName, Map<String, String> parameters) {
        this.commandName = commandName;
        this.parameters = parameters;
    }

    //getters for the constructor variables
    public String getCommandName() {
        return commandName;
    }

    public Map<String, String> getParameters() {
        return parameters;
    }

    
    // Convert object to JSON string manually with an established structure
    public String toJson() {
    	//starting with curly brace
        StringBuilder json = new StringBuilder("{");
        
        //Adding commandName followed by commandName value
        json.append("\"commandName\":\"").append(commandName).append("\",");
        
        // adding the parameter section (starting)
        // should allow for greater detail to be included in the request
        json.append("\"parameters\":{");
        
        // creating an variable for comma indicator
        boolean first = true;
        
        for (Map.Entry<String, String> entry : parameters.entrySet()) {
        	// if it is not the first entry, then add a comma
            if (!first) json.append(",");
            
            //Add the value pair
            json.append("\"").append(entry.getKey()).append("\":\"").append(entry.getValue()).append("\"");
            
            // will change first to false after the first round
            first = false;
        }
        json.append("}}"); /// close the parameter section
        return json.toString();
    }

    // Convert JSON string back to object manually
    /*public static ParkingRequest fromJson(String json) {
        JSONObject jsonObj = new JSONObject(json);
        String commandName = jsonObj.getString("commandName");

        Map<String, String> params = new HashMap<>();
        JSONObject paramsObj = jsonObj.getJSONObject("parameters");
        
        for (String key : paramsObj.keySet()) {
            params.put(key, paramsObj.getString(key));
        }

        return new ParkingRequest(commandName, params);
    }*/

    // retreiving string and turning to object
    public static ParkingRequest fromJson(String json) {
    	// removes string formatting for easier processing
        json = json.replace("{", "").replace("}", "").replace("\"", "");
       
        //Splitting at the commas
        String[] parts = json.split(",");
        
        //Separtating at colon for individual values
        String commandName = parts[0].split(":")[1];

        // splitting at colons for key value pairing for parameters since they are nested
        Map<String, String> params = new HashMap<>();
        for (int i = 1; i < parts.length; i++) {
            String[] kv = parts[i].split(":");
            params.put(kv[0], kv[1]);
        }

        return new ParkingRequest(commandName, params);
    }
}

/*import com.google.gson.*;
import java.util.Properties;

public class ParkingRequest {
    private String commandName;
    private Properties parameters;

    // Constructor
    public ParkingRequest(String commandName, Properties parameters) {
        this.commandName = commandName;
        this.parameters = parameters;
    }

    // Getter for commandName
    public String getCommandName() {
        return commandName;
    }

    // Getter for parameters
    public Properties getParameters() {
        return parameters;
    }

    // Convert object to JSON string
    public String toJson() {
        return new Gson().toJson(this);
    }

    // Convert JSON string back to object
    public static ParkingRequest fromJson(String json) {
        return new Gson().fromJson(json, ParkingRequest.class);
    }

    // Override toString for better debugging
    @Override
    public String toString() {
        return "Command: " + commandName + ", Parameters: " + parameters.toString();
    }
}*/

/*
 * References:
 * 
 * Professor Saad. 2017. "Java JSON Kar File Download." YouTube. Published April 5, 2017.
 *    https://www.youtube.com/watch?v=joAxQtSaErE. 
 *    
 * Kass. 2017. "Importing GSON into Eclipse." Medium. Published December 16, 2017.
 *    https://medium.com/programmers-blockchain/importing-gson-into-eclipse-ec8cf678ad52
 * */