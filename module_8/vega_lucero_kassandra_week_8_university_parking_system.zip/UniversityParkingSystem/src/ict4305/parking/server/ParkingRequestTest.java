
/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 *      May 25, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.parking.server;

//import ict4305.parking.server.ParkingRequest;
import org.junit.jupiter.api.Test;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class ParkingRequestTest {

	/*
	 * The test checks that a ParkingRequest object is correctly converted into a JSON string.
     */
    @Test
    public void testToJson() {
        Map<String, String> params = new HashMap<>();
        params.put("firstName", "Rob"); // simulating adding Rob as a customer

        //Creating a parking request using a "CUSTOMER" command
        ParkingRequest request = new ParkingRequest("CUSTOMER", params); 
        String json = request.toJson(); // turning the request into a string

        // Comparing the JSON output (should include command name and the parameter)
        assertTrue(json.contains("\"commandName\":\"CUSTOMER\""));
        assertTrue(json.contains("\"firstName\":\"Rob\""));
    }

    // This one has issues (same as the command prompt issue?)
    @Test
    public void testFromJson() {
    	// creating a JSON string to represent a valid parking request
        String json = "{\"commandName\":\"CAR\",\"parameters\":{\"license\":\"ROB4CO\",\"customer\":\"CUST1\"}}";
        
        // Print raw JSON before parsing
        System.out.println("Raw JSON Input: " + json);

        //Turning the string back to a ParkingRequest object
        ParkingRequest request = ParkingRequest.fromJson(json);
        
        //Debugging using print statements
        System.out.println("Command: " + request.getCommandName());
        System.out.println("License: " + request.getParameters().get("license"));
        System.out.println("Customer: " + request.getParameters().get("customer"));

        
        // Validating the object has the correct information (after deserialization)
        assertEquals("CAR", request.getCommandName());
        assertEquals("ROB4CO", request.getParameters().get("license"));
        assertEquals("CUST1", request.getParameters().get("customer"));
    }
}
