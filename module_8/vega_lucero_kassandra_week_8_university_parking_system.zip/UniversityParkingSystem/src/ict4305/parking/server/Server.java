/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 *      May 25, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.parking.server;

import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
	// Indicating port 8080 will be used
    private static final int PORT = 8080;
    
    // Christian indicated needed to have a map for the customer and car databases
    private static final Map<String, String> customerDatabase = new HashMap<>(); // to store registered customers
    private static final Map<String, String> carDatabase = new HashMap<>(); // to store cars with respective owners

    public static void main(String[] args) {
    	// using try will close the ServerSocket when done
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
        	// to show that the server is working (started)
            System.out.println("Server running on port " + PORT + "...");

            // the while loop makes it so that the server is continuously listening for incoming request
            while (true) {
            	// this makes it so that the server accepts a connection
            	// Christian mentioned this creates a block of some sort
                Socket clientSocket = serverSocket.accept();
                
                // Christian mentioned implementing the code would need to be done by creating a new thread
                // as well as a new ClientHandler
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
        	// if there is an error a stacktrace will be printed
            e.printStackTrace();
        }
    }

    // Christian indicated this should moved from its own class and added to the server class (not too sure why)
    static class ClientHandler implements Runnable {
    	// the socket will be used to represent the  client's connection
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
        	// using try closes after being used
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {

            	// reading clients input and should be in expected format
                String jsonRequest = in.readLine();
                
                //Changing from JSON string to ParkingRequest Object
                ParkingRequest request = ParkingRequest.fromJson(jsonRequest);
                
                // Creating the corresponding object
                ParkingResponse response = processRequest(request);

                out.println(response.toJson());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        // to create the ParkingRequest object
        private ParkingResponse processRequest(ParkingRequest request) {
            // check commandName
        	String command = request.getCommandName();
        	// gathers parameters for the command Name
            Map<String, String> params = request.getParameters();

            // Two commandNames are indicated "CUSTOMER" and "CAR" anything else returns command not found message
            switch (command.toUpperCase()) {
                case "CUSTOMER":
                    return registerCustomer(params);
                case "CAR":
                    return registerCar(params);
                default:
                    return new ParkingResponse(400, "Unknown command");
            }
        }

        // registering the customer using parameters 
        private ParkingResponse registerCustomer(Map<String, String> params) {
        	// this will probably need to be changed to their full name
            String customerName = params.get("firstname");
            if (customerName == null) return new ParkingResponse(400, "Invalid request format");

            // customer Id will include "CUST" at the beginning by default
            String customerId = "CUST" + (customerDatabase.size() + 1);
             // adding to data base to keep track of 
            //all customers that have been registered
            customerDatabase.put(customerId, customerName); 
            return new ParkingResponse(200, "Customer registered: " + customerId);
        }

        // registering the car to the owner
        private ParkingResponse registerCar(Map<String, String> params) {
            String licensePlate = params.get("license");
            String customerId = params.get("customer");

            // checking for any null values
            if (licensePlate == null || customerId == null) return new ParkingResponse(400, "Invalid request format");
            //checking to see if the enrty exists in the database already
            // if not customer is not found
            if (!customerDatabase.containsKey(customerId)) return new ParkingResponse(404, "Customer not found");

            // if customer is found car is added to data base with owner information
            carDatabase.put(licensePlate, customerId);
            return new ParkingResponse(200, "Car registered: " + licensePlate + " assigned to " + customerId);
        }
    }
}

/*import java.io.*;
import java.net.*;
import java.util.*;

public class Server {
    private static final int PORT = 8080;
    private static final Map<String, String> customerDatabase = new HashMap<>();
    private static final Map<String, String> carDatabase = new HashMap<>();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is running on port " + PORT + "...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected: " + clientSocket.getInetAddress());
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static class ClientHandler implements Runnable {
        private Socket clientSocket;

        public ClientHandler(Socket clientSocket) {
            this.clientSocket = clientSocket;
        }

        @Override
        public void run() {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                 PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)) {
                
                String jsonRequest = in.readLine();
                ParkingRequest request = ParkingRequest.fromJson(jsonRequest);
                ParkingResponse response = processRequest(request);
                
                out.println(response.toJson());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private ParkingResponse processRequest(ParkingRequest request) {
            String command = request.getCommandName();
            Properties params = request.getParameters();

            switch (command.toUpperCase()) {
                case "CUSTOMER":
                    return registerCustomer(params);
                case "CAR":
                    return registerCar(params);
                default:
                    return new ParkingResponse(400, "Unknown command");
            }
        }

        private ParkingResponse registerCustomer(Properties params) {
            String customerName = params.getProperty("firstname");
            if (customerName == null) return new ParkingResponse(400, "Invalid request format");

            String customerId = "CUST" + (customerDatabase.size() + 1);
            customerDatabase.put(customerId, customerName);
            return new ParkingResponse(200, "Customer registered: " + customerId);
        }

        private ParkingResponse registerCar(Properties params) {
            String licensePlate = params.getProperty("license");
            String customerId = params.getProperty("customer");

            if (licensePlate == null || customerId == null) return new ParkingResponse(400, "Invalid request format");
            if (!customerDatabase.containsKey(customerId)) return new ParkingResponse(404, "Customer not found");

            carDatabase.put(licensePlate, customerId);
            return new ParkingResponse(200, "Car registered: " + licensePlate + " assigned to " + customerId);
        }
    }
}*/

