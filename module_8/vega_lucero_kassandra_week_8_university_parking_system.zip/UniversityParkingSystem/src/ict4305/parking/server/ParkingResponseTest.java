/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 *      May 25, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.parking.server;

//import ict4305.parking.server.ParkingResponse;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ParkingResponseTest {

 
     // Checks that the generated JSON string exactly matches the expected format.
    @Test
    public void testToJson() {
        // Creating a ParkingResponse object with sample values.
    	
        // Christian suggested to use a status code of 200 and a message indicating "Success".
        ParkingResponse response = new ParkingResponse(200, "Success");
        
        // Turn the object to a JSON string
        String json = response.toJson();
        
        // Debugging print statement
        System.out.println("Generated JSON from toJson(): " + json);
        
        // Creating the expected JSON string
        String expectedJson = "{\"statusCode\":200,\"message\":\"Success\"}";
        
        // Comparing expected with generated string
        assertEquals(expectedJson, json, "The JSON generated should exactly match the expected output.");
    }

    
     // Verifying that the object's fields match the values in the JSON string.
    @Test
    public void testFromJson() {
        //Creating a JSON string
        String json = "{\"statusCode\":404,\"message\":\"Customer not found\"}";
        
        //Debugging by printing the raw JSON input to the console.
        System.out.println("Raw JSON input for fromJson(): " + json);
        
        //Turning the JSON string back to create a ParkingResponse object.
        ParkingResponse response = ParkingResponse.fromJson(json);
        
        //Debugging by printing the deserialized ParkingResponse object using the overridden toString() method.
        System.out.println("Deserialized ParkingResponse: " + response.toString());
        
        //checking that the deserialized object's statusCode matches the expected value (404).
        assertEquals(404, response.getStatusCode(), "Deserialized statusCode should be 404.");
        
        // checking that the deserialized object's message matches the expected value ("Customer not found").
        assertEquals("Customer not found", response.getMessage(), "Deserialized message should match the expected value.");
    }
}