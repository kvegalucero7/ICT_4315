/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * May 11, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.time.LocalDate;
import ict4305.university.parking.Money;
import ict4305.university.parking.Car;

public class DayChargeDecorator extends ParkingChargeDecorator {
	private Money weekendCharge = new Money(500); //Fixed $5.00 for weekend added to charge
	
	public DayChargeDecorator(ParkingChargeCalculator calculator) {
		super(calculator);
	}
	
	@Override
	public Money calculateCharge(LocalDateTime entryTime, LocalDateTime exitTime, Car car) {
		//System.out.println("DAY CHARGE charges 5.00 for the weekend");
		Money baseCharge = super.calculateCharge(entryTime,  exitTime, car);
		
		if (entryTime.equals(exitTime)) {
			return new Money(0);
		}
		
		// Checking if parking happens on the weekend changing from prior to account for thurs entry and tues exit
		LocalDate currentDay = entryTime.toLocalDate();
		while (!currentDay.isAfter(exitTime.toLocalDate())) {
			if (currentDay.getDayOfWeek() == DayOfWeek.SATURDAY || currentDay.getDayOfWeek() == DayOfWeek.SUNDAY ) {
				return baseCharge.add(weekendCharge);
			}
			currentDay = currentDay.plusDays(1); // Move to next day
		}	
		return baseCharge; // no extra fee for weekdays
	}
}
