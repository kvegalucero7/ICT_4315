/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * May 11, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;
import ict4305.university.parking.charges.*;
import ict4305.university.parking.charges.strategy.HourlyRateStrategy;
import ict4305.university.parking.*;

class CarSizeChargeDecoratorTest {

	// testing for compact car discount which should be 20%
	@Test
	void testCompactCarDiscount() {
		ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(1000)); // $10.00 base rate
		ParkingChargeCalculator carSizeDecorator = new CarSizeChargeDecorator(baseCalculator);
		
		Car car = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001");
		Money charge = carSizeDecorator.calculateCharge(
				LocalDateTime.of(2025,  5, 1, 10, 0),
				LocalDateTime.of(2025,  5, 1, 11, 0),
				car
			);
		
		assertEquals(new Money(800), charge, "Compact cars should receive a 20% discount");
	}
	
	
	// Testing cost with no compact car discount
	@Test
	void testSUVNoDiscount() {
		ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(1000)); // $10.00 base rate
		ParkingChargeCalculator carSizeDecorator = new CarSizeChargeDecorator(baseCalculator);
		
		Car car = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001");
		Money charge = carSizeDecorator.calculateCharge(
				LocalDateTime.of(2025,  5, 1, 10, 0),
				LocalDateTime.of(2025,  5, 1, 11, 0),
				car
			);
		
		assertEquals(new Money(1000), charge, "SUVs should not receive a 20% discount");
	}
	
	// Testing not being in the parking lot long enough
	@Test
    public void testZeroDurationCharge() {
        ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
        ParkingChargeCalculator sizeDecorator = new CarSizeChargeDecorator(baseCalculator);

		Car car = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001");
        Money charge = sizeDecorator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 1, 10, 0), // same entry and exit time
            car
        );

        assertEquals(new Money(0), charge, "Zero duration parking should result in zero charge.");
    }

	// Testing an exit time that is before the entry time
    @Test
    public void testNegativeDurationThrowsException() {
        ParkingChargeCalculator baseCalculator = new BaseChargeCalculator(new Money(500));
        ParkingChargeCalculator sizeDecorator = new CarSizeChargeDecorator(baseCalculator);

		Car car = new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.SUV, "CI00001");

		// testing entry 12 pm and exit 10 am on the same day
        assertThrows(IllegalArgumentException.class, () -> {
            sizeDecorator.calculateCharge(
                LocalDateTime.of(2025, 5, 1, 12, 0),
                LocalDateTime.of(2025, 5, 1, 10, 0),
                car
            );
        }, "Negative parking duration should throw an exception.");
    }


}
