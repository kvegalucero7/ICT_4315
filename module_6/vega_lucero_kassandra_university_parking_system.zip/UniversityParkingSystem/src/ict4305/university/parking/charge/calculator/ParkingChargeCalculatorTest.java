/*
 * Kassandra Vega Lucero
 * 
 * ICT 4315: Week 3 Parking System Charge Calculator
 *      (Continuation of ICT 4305)
 * May 11, 2025
 * Instructor: Nathan Braun
 * 
 */
package ict4305.university.parking.charge.calculator;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import ict4305.university.parking.*;
import ict4305.university.parking.charges.strategy.*;
import java.time.LocalDateTime;
import java.time.LocalDate;

class ParkingChargeCalculatorTest {

	// Testing Strictly hourly
	@Test
    public void testStandardChargeCalculation() {
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(500)); // $5 per hour

        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 1, 12, 0),
  		    new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")

        );

        assertEquals(new Money(1000), charge, "Charge should be correct for 2 hours at $5 per hour.");
    }

	// Testing entering and exiting right away
    @Test
    public void testZeroDurationCharge() {
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(500));

        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 1, 10, 0), // less than a minute
  		    new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")

        );

        assertEquals(new Money(0), charge, "Zero duration parking should result in zero charge.");
    }

    // Testing exit time before entry time
    @Test
    public void testNegativeDurationThrowsException() {
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(500));

        assertThrows(IllegalArgumentException.class, () -> {
            calculator.calculateCharge(
                LocalDateTime.of(2025, 5, 1, 12, 0),
                LocalDateTime.of(2025, 5, 1, 10, 0),
  		    new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")

            );
        }, "Negative parking duration should throw an exception.");
    }

    // Testing rounding up to an hour after using for 30 minutes
    @Test
    public void testFractionalHourCharge() {
        ParkingChargeCalculator calculator = new HourlyRateStrategy(new Money(500)); // $5 per hour

        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 1, 10, 0),
            LocalDateTime.of(2025, 5, 1, 10, 30),
  		    new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")

        );

        assertEquals(new Money(500), charge, "Fractional hours should round up to the nearest full hour.");
    }

    // Testing using hourly charge with discount for compact car and considering weekend charge
    @Test
    public void testFactoryCreatesCalculatorWithDecorators() {
    	Address address = new Address("321 University Drive", "", "Denver", "CO", "80204");
		ParkingLot lot = new ParkingLot(
				"Lot1", 
				address, 
				200, 50, 500, // Issue to resolve in the future the base rate is coming from the parking lot and not hourly
				new HourlyRateStrategy(new Money(500)));

        lot.setCarSizeBasedPricing(true); // Enables compact car discount
        lot.setDayRestrictedPricing(true); // Enable weekend charge

        ParkingChargeCalculator calculator = ChargeCalculatorFactory.createChargeCalculator(lot);
        Money charge = calculator.calculateCharge(
            LocalDateTime.of(2025, 5, 4, 10, 0),  // Sunday (Weekend)
            LocalDateTime.of(2025, 5, 4, 12, 0),
  		    new Car("123ABC", LocalDate.now().plusYears(1), "123ABC", CarType.COMPACT, "CI00001")

        );

        assertEquals(new Money(1300), charge, "Factory should apply size-based discount and weekend charge correctly.");
    }
}
